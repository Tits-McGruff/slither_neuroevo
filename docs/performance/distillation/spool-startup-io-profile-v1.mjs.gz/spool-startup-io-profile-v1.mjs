import {createRequire} from 'node:module';
import {createHash, webcrypto} from 'node:crypto';
import {readFileSync,lstatSync,writeFileSync} from 'node:fs';
import {readFile,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import assert from 'node:assert/strict';
const base='/srv/opt/apps/slither_neuroevo/native/target/evolved-real-clock-20261018';
const root=join(base,'spool-full64g-candidate-workspace');
assert(!lstatSync(root).isSymbolicLink());
const require=createRequire(join(base,'checkout/package.json'));
const Database=require('better-sqlite3');
const db=new Database(join(root,'metadata.sqlite'),{readonly:true,fileMustExist:true});
const records=[];
function io(){const data=readFileSync('/proc/self/io','utf8');return BigInt(data.match(/^read_bytes: ([0-9]+)$/m)[1]);}
for(const [role,offset] of [['serial',32768],['parallel4',49152],['parallel4',40960],['serial',57344]]){
 const rows=db.prepare('SELECT filename,bytes,descriptor FROM chunks ORDER BY ordinal LIMIT 4096 OFFSET ?').all(offset);
 assert.equal(rows.length,4096);let completedBytes=0;
 for(const row of rows)assert(/^[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{64}\.teacher$/.test(row.filename));
 const beforeIo=io();const before=performance.now();const cpu=process.cpuUsage();
 async function verify(row){const path=join(root,row.filename);const metadata=await lstat(path);assert(metadata.isFile()&&!metadata.isSymbolicLink());assert.equal(metadata.size,row.bytes);
  const bytes=await readFile(path);const actual=Buffer.from(await webcrypto.subtle.digest('SHA-256',bytes)).toString('hex');assert.equal(actual,JSON.parse(row.descriptor).sha256);completedBytes+=bytes.length;}
 if(role==='serial')for(const row of rows){const path=join(root,row.filename);const metadata=lstatSync(path);assert(metadata.isFile()&&!metadata.isSymbolicLink());assert.equal(metadata.size,row.bytes);const bytes=readFileSync(path);assert.equal(createHash('sha256').update(bytes).digest('hex'),JSON.parse(row.descriptor).sha256);completedBytes+=bytes.length;}
 else for(let i=0;i<rows.length;i+=4)await Promise.all(rows.slice(i,i+4).map(verify));
 const ms=performance.now()-before;const usage=process.cpuUsage(cpu);
 const result={role,offset,objects:rows.length,verifiedBytes:completedBytes,milliseconds:ms,processCpuMs:(usage.user+usage.system)/1000,physicalReadBytes:(io()-beforeIo).toString(),peakRssBytes:process.memoryUsage().rss};records.push(result);console.log(JSON.stringify(result));
}
db.close();writeFileSync(join(base,'spool-startup-io-profile-20261019.json'),JSON.stringify({scope:'Read-only disjoint-range startup verification diagnostics; shared host/cache states differ; not capacity qualification.',records},null,2)+'\n',{flag:'wx'});

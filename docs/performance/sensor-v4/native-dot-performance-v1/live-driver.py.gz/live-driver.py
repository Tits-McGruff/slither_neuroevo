"""Owned sequential v4 P0/P1 live measurements; aggregate resources only."""
from pathlib import Path
import subprocess,json,os,time
base=Path('/srv/opt/apps/slither_neuroevo/native/target/evolved-real-clock-20261018/checkout')
frozen=base/'native/target/live-replay-occupancy-20261023'
slither=frozen/'slither'
source='b066380f41085a83f8aed9445a26475f569c78d72aedcde238a1580aed2f3925'
check="try{const a=require(process.argv[1]);process.exit(a.nativeAddonSourceSha256()===process.argv[2]&&a.nativeAddonBuildClass()==='test-hooks'?0:1)}catch{process.exit(1)}"
assert subprocess.run(['node','-e',check,str(slither/'native/target/ci-panic-hooks.node'),source],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
python=base.parent/'pyrl-replay-capacity-20261019/.venv/bin/python'
for workload in ['P0','P1']:
 prefix=base/'native/target'/('live-large-'+workload+'-dot-accumulators-20261024')
 report=Path(str(prefix)+'.json');resources=Path(str(prefix)+'.resources.jsonl')
 workspace=Path(str(prefix)+'-workspace');status=Path(str(prefix)+'.status.json')
 assert not any(p.exists() for p in [report,resources,workspace,status])
 started=time.monotonic()
 observer=subprocess.Popen(['python3','-B',str(slither/'scripts/qualification/system-resource-observer.py'),
  '--output',str(resources),'--interval-seconds','30','--samples','60','--watch-pid',str(os.getpid())],
  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 code=1
 try:
  args=['node','node_modules/tsx/dist/cli.mjs','scripts/qualification/live-distillation.ts',
   '--pyrl-root',str(frozen/'pyrl'),'--python',str(python),'--device','cpu','--workers','4',
   '--report',str(report),'--spool-gib','4','--workload',workload,
   '--student-artifact',str(base/'native/target/live-capacity-overlap-20261023/large-motion32-student.slither-brain'),
   '--contention-seconds','60','--generation-boundaries','3','--workspace',str(workspace),
   '--capacity-graph','large','--checkpoint-envelope-mib','768',
   '--library-fixtures',str(base/'native/target/live-capacity-fixtures-20261023/library-inputs/index.json')]
  code=subprocess.run(args,cwd=slither,timeout=1800).returncode
 finally:
  observer.terminate()
  try:observer.wait(timeout=10)
  except subprocess.TimeoutExpired:observer.kill();observer.wait()
  status.write_text(json.dumps({'exitCode':code,'elapsedSeconds':time.monotonic()-started,
                               'nativeSourceSha256':source})+'\n')
 if code:raise SystemExit(code)
 print(workload,'live measurement complete',flush=True)

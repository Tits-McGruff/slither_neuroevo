//! Conservative SSE2 far-rejection prototype. No production source, graph or RNG changes.
use std::hint::black_box;
use std::time::Instant;
const THRESHOLD: f64 = 0.35;
const BLOCK: usize = 256;
const MAX_PROOF: usize = 1 << 30;
const GUARD: f64 = 1.0001;

fn ordered(left: &[f32], right: &[f32], mut sum: f64, cutoff: f64) -> Option<f64> {
    for (a, b) in left.chunks(BLOCK).zip(right.chunks(BLOCK)) {
        for (&x, &y) in a.iter().zip(b) {
            let d = f64::from(x) - f64::from(y); sum += d * d;
        }
        if sum > cutoff { return None; }
    }
    Some(sum)
}

fn original(left: &[f32], right: &[f32]) -> bool {
    assert_eq!(left.len(), right.len());
    if left.is_empty() { return false; }
    let cutoff = THRESHOLD * THRESHOLD * left.len() as f64 * 1.000001;
    ordered(left, right, 0.0, cutoff)
        .is_some_and(|sum| (sum / left.len() as f64).sqrt() <= THRESHOLD)
}

#[derive(Debug)]
enum EvolutionError { PopulationShape { reason: &'static str } }
struct PopulationGenome<'a> { weights: &'a [f32] }
#[path = "simd_kernels.rs"] mod simd_kernels;
const SPECIES_DISTANCE_THRESHOLD: f64 = THRESHOLD;
const SPECIES_DISTANCE_SCAN_BLOCK: usize = BLOCK;
const SPECIES_DISTANCE_PROBE_MIN_WEIGHTS: usize = 4096;
const SPECIES_NORM_MAX_WEIGHTS: usize = MAX_PROOF;
const SPECIES_NORM_ROUNDING_GUARD: f64 = GUARD;
fn species_probe_proves_far(left: &[f32], right: &[f32], prefix: f64, far_limit: f64) -> bool {
    if !(SPECIES_DISTANCE_PROBE_MIN_WEIGHTS..=SPECIES_NORM_MAX_WEIGHTS).contains(&left.len())
        || prefix
            <= SPECIES_DISTANCE_THRESHOLD
                * SPECIES_DISTANCE_THRESHOLD
                * SPECIES_DISTANCE_SCAN_BLOCK as f64
                * SPECIES_NORM_ROUNDING_GUARD
    {
        return false;
    }
    let budget = ((2.0 * far_limit * SPECIES_DISTANCE_SCAN_BLOCK as f64 / prefix).ceil() as usize)
        .min(left.len())
        .saturating_sub(SPECIES_DISTANCE_SCAN_BLOCK);
    let end = SPECIES_DISTANCE_SCAN_BLOCK + budget;
    let mut sum = prefix;
    for (a, b) in left[SPECIES_DISTANCE_SCAN_BLOCK..end]
        .chunks(SPECIES_DISTANCE_SCAN_BLOCK)
        .zip(right[SPECIES_DISTANCE_SCAN_BLOCK..end].chunks(SPECIES_DISTANCE_SCAN_BLOCK))
    {
        let block_sum = crate::simd_kernels::squared_distance_f64_sse2(a, b);
        sum += block_sum;
        if sum > far_limit * SPECIES_NORM_ROUNDING_GUARD {
            return true;
        }
        if block_sum
            < SPECIES_DISTANCE_THRESHOLD
                * SPECIES_DISTANCE_THRESHOLD
                * a.len() as f64
                * SPECIES_NORM_ROUNDING_GUARD
        {
            break;
        }
    }
    false
}

fn genomes_share_species(
    left: &PopulationGenome,
    right: &PopulationGenome,
) -> Result<bool, EvolutionError> {
    if left.weights.len() != right.weights.len() {
        return Err(EvolutionError::PopulationShape {
            reason: "species genomes have incompatible weights",
        });
    }
    if left.weights.is_empty() {
        // TypeScript computes `Math.sqrt(0 / 0)`, yielding NaN; its `<=`
        // threshold comparison is then false, so every draw-free genome forms
        // its own diagnostic species without invalidating evolution.
        return Ok(false);
    }
    // Squared differences are nonnegative. Reject distant genomes early, but
    // leave a generous guard above the threshold so close comparisons still
    // take the original complete sum and sqrt path in the same weight order.
    let far_limit = SPECIES_DISTANCE_THRESHOLD
        * SPECIES_DISTANCE_THRESHOLD
        * left.weights.len() as f64
        * 1.000_001;
    let mut sum_squared = 0.0_f64;
    for (block_index, (left_block, right_block)) in left
        .weights
        .chunks(SPECIES_DISTANCE_SCAN_BLOCK)
        .zip(right.weights.chunks(SPECIES_DISTANCE_SCAN_BLOCK))
        .enumerate()
    {
        for (&left_weight, &right_weight) in left_block.iter().zip(right_block) {
            let difference = f64::from(left_weight) - f64::from(right_weight);
            sum_squared += difference * difference;
        }
        // Later nonnegative terms cannot undo a far rejection. Close decisions
        // still use every original addition and the original final sqrt.
        if sum_squared > far_limit
            || (block_index == 0
                && species_probe_proves_far(&left.weights, &right.weights, sum_squared, far_limit))
        {
            return Ok(false);
        }
    }
    Ok((sum_squared / left.weights.len() as f64).sqrt() <= SPECIES_DISTANCE_THRESHOLD)
}

fn candidate(left: &[f32], right: &[f32]) -> bool {
    genomes_share_species(&PopulationGenome {weights: left}, &PopulationGenome {weights: right}).unwrap()
}

fn complete(left: &[f32], right: &[f32]) -> bool {
    let mut sum = 0.0;
    for (&a, &b) in left.iter().zip(right) {
        let d = f64::from(a) - f64::from(b); sum += d * d;
    }
    (sum / left.len() as f64).sqrt() <= THRESHOLD
}

fn values(count: usize, salt: u64) -> Vec<f32> {
    let mut state = salt;
    (0..count).map(|_| {
        state ^= state << 13; state ^= state >> 7; state ^= state << 17;
        (((state >> 40) as f32 / 16777216.0) - 0.5) * 1.1
    }).collect()
}

fn timed(f: fn(&[f32], &[f32]) -> bool, a: &[f32], bank: &[Vec<f32>], iterations: usize) -> f64 {
    let start = Instant::now();
    for i in 0..iterations {
        black_box(f(black_box(a), black_box(&bank[i % bank.len()])));
    }
    start.elapsed().as_secs_f64()
}

fn main() {
    assert!(is_x86_feature_detected!("sse2"));
    let mut decisions = 0;
    for count in [0, 1, 255, 256, 257, 4095, 4096, 4097, 8192, 494306] {
        for value in [0.0_f32, f32::from_bits(1), 0.1, f32::from_bits(0.35_f32.to_bits()-1),
                      0.35, f32::from_bits(0.35_f32.to_bits()+1), 0.35001, 0.3501, 0.5, f32::MAX] {
            let a = vec![0.0; count]; let mut b = vec![value; count];
            for spike in [None, Some(0), count.checked_sub(1)] {
                if let Some(i) = spike.filter(|&i| i < count) { b[i] = 10.0; }
                let expected = complete(&a, &b);
                assert_eq!(original(&a, &b), expected);
                assert_eq!(candidate(&a, &b), expected, "count={count},value={value},spike={spike:?}");
                decisions += 1;
            }
        }
        for salt in 1..=20 {
            let a = values(count, salt);
            let b = values(count, salt+100);
            assert_eq!(candidate(&a, &b), complete(&a, &b));
            decisions += 1;
        }
    }
    println!("{{\"kind\":\"species-distance-production-copy-v1\",\"exactDecisions\":{decisions},\"records\":[");
    let mut separator = "";
    for case in ["distant-hot", "distant-stream", "similar", "prefix-spike-close", "prefix-skew-cutoff"] {
        let count = 494306;
        let a = values(count, 71);
        let bank: Vec<Vec<f32>> = if case == "distant-stream" {
            (0..64).map(|salt| values(count, salt+100)).collect()
        } else if case == "distant-hot" {
            vec![values(count, 91)]
        } else {
            let mut b = a.clone();
            if case == "similar" {
                for (i, v) in b.iter_mut().enumerate().step_by(31) { *v += (i % 7) as f32 * 0.01; }
            } else if case == "prefix-spike-close" {
                for v in &mut b[..BLOCK] { *v += 1.0; }
            } else {
                for (v, &x) in b.iter_mut().zip(&a) { *v = x + f32::from_bits(0.35_f32.to_bits()+1); }
                for (v, &x) in b[..BLOCK].iter_mut().zip(&a[..BLOCK]) { *v = x + 0.36; }
            }
            vec![b]
        };
        for b in &bank { assert_eq!(candidate(&a,b),complete(&a,b)); }
        let iterations = if case == "distant-stream" {128} else {256};
        for pass in 0..8 {
            let old_first = matches!(pass % 4, 0 | 3);
            let (old,new) = if old_first {
                (timed(original,&a,&bank,iterations),timed(candidate,&a,&bank,iterations))
            } else {
                let new = timed(candidate,&a,&bank,iterations);
                (timed(original,&a,&bank,iterations),new)
            };
            print!("{separator}{{\"case\":\"{case}\",\"pass\":{pass},\"oldFirst\":{old_first},\"iterations\":{iterations},\"originalSeconds\":{old},\"candidateSeconds\":{new}}}");
            separator = ",\n";
        }
    }
    println!("]}}");
}

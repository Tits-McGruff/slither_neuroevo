"""Measure only owned native children; aggregate context is separate from timing."""
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    """Run one immutable ABBA comparison with aggregate endpoint/continuous coverage."""
    repo=Path.cwd()
    root=repo/"native/target/observation-quality-window-20261024"
    observer=repo/"scripts/qualification/system-resource-observer.py"
    driver=repo/"scripts/qualification/compare-sensor-workloads.py"
    candidate=root/"candidate.exe"
    if candidate.exists():
        raise RuntimeError("comparison candidate already exists")
    shutil.copyfile(repo/"native/target/release/sensor-v4-qualification.exe",candidate)
    def snapshot(name):
        """Capture anonymous aggregate counters without process collection."""
        subprocess.run([sys.executable,"-B",str(observer),"--output",str(root/name),
                        "--samples","1"],check=True)
    snapshot("comparison-before-resources.jsonl")
    process=subprocess.Popen([sys.executable,"-B",str(driver),
        "--baseline",str(root/"baseline.exe"),"--candidate",str(candidate),
        "--baseline-source","6205b45fcf296375269c2fc7c75ea321f61a90393650dcfff54c365f0f71a37f",
        "--directory",str(root/"comparison"),"--scenario","P1","--workers","4",
        "--ray-cap","256","--ray-batch","65536","--warmup","600","--steps","1200"])
    resource=subprocess.Popen([sys.executable,"-B",str(observer),
        "--output",str(root/"comparison-resources.jsonl"),"--interval-seconds","30",
        "--samples","120","--watch-pid",str(process.pid)])
    try:
        code=process.wait()
        snapshot("comparison-after-resources.jsonl")
        if code:
            raise RuntimeError("native comparison failed")
    finally:
        # The observer checks only this owned child and exits after it finishes.
        resource.wait(timeout=60)
    print("owned comparison and aggregate observer complete",flush=True)

if __name__=="__main__":
    main()

"""Read-only cold admission of this task's last periodic six-hour job snapshot."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path('/srv/opt/apps/slither_neuroevo/native/target/live-window-six-hour-20261022')
sys.path.insert(0,str(ROOT/'pyrl'))
from pyrl_trainer.distillation_checkpoint import load_job_checkpoint
from pyrl_trainer.distillation_job import trainer_source_sha256, SOURCE_FILES
from pyrl_trainer.brain_artifact import encode_brain_artifact

pointer=json.loads((ROOT/'run-verified-loader/job/sustain-checkpoint.json').read_text())
checkpoint=Path(pointer['checkpoint']).resolve()
assert checkpoint.is_relative_to(ROOT/'run-verified-loader/job/checkpoints')
report=json.loads((ROOT/'six-hour-window-verified-loader.json').read_text())
job=load_job_checkpoint(checkpoint)
assert trainer_source_sha256()==report['sustain']['trainerSourceSha256']
assert job.trainer.completed_updates<=report['sustain']['updates']
assert job.replay.owned_bytes<=256*1024**2
retained=sorted(checkpoint.parent.glob('job-*.distill-job'))
assert len(retained)==3
hasher=hashlib.sha256()
with checkpoint.open('rb') as stream:
 for block in iter(lambda:stream.read(1024**2),b''): hasher.update(block)
receipt={'schemaVersion':1,'kind':'six-hour-periodic-job-cold-admission-v1',
 'scope':'Last durable periodic trainer boundary, not final running-world or final optimizer recovery',
 'trainerSourceSha256':trainer_source_sha256(),'retainedCheckpointFiles':len(retained),
 'checkpointBytes':checkpoint.stat().st_size,'checkpointSha256':hasher.hexdigest(),
 'checkpointSerial':job.serial,'restoredUpdates':job.trainer.completed_updates,
 'completedWindowUpdates':report['sustain']['updates'],'replayOwnedBytes':job.replay.owned_bytes,
 'replayChunks':job.replay.retained_chunks,'cursor':job.client.cursor,
 'environment':job.environment,'sampler':job.sampler.checkpoint_fields()}
artifact=encode_brain_artifact(job.model.manifest,job.model.export_weights(),
 {'schemaVersion':1,'sourceKind':'distilled','details':{'qualification':'six-hour-live-periodic-boundary',
  'jobId':job.job_id,'updates':job.trainer.completed_updates,
  'trainerSourceSha256':trainer_source_sha256(),'checkpointSha256':hasher.hexdigest()}})
(ROOT/'periodic-student.slither-brain').write_bytes(artifact.data)
receipt['artifactSha256']=artifact.sha256
receipt['weightsSha256']=artifact.weights_sha256
(ROOT/'checkpoint-restore.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ('restoredUpdates','retainedCheckpointFiles','checkpointBytes','replayOwnedBytes','artifactSha256')}))

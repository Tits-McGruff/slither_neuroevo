use std::cmp::Ordering;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)] struct DistanceOrderKey(i64);

#[derive(Clone, Copy, Debug, PartialEq, Eq)] struct PelletCandidate { pellet: usize, distance_squared: DistanceOrderKey }

const PELLET_RADIX_CAPACITY: usize = 1024;

fn compare_pellet_candidates(left: &PelletCandidate, right: &PelletCandidate) -> Ordering {
    left.distance_squared
        .cmp(&right.distance_squared)
        .then_with(|| left.pellet.cmp(&right.pellet))
}

fn sort_pellet_candidates(values: &mut [PelletCandidate]) {
    if values.len() <= 128 || values.len() > PELLET_RADIX_CAPACITY {
        values.sort_unstable_by(compare_pellet_candidates);
    } else if values.windows(2).all(|pair| compare_pellet_candidates(&pair[0], &pair[1]) != Ordering::Greater) {
        // Keep the comparison sort's adaptive behavior for already ordered data.
    } else if values.windows(2).all(|pair| compare_pellet_candidates(&pair[0], &pair[1]) != Ordering::Less) {
        values.reverse();
    } else {
        sort_pellet_candidates_buffered(values);
    }
}

#[inline(never)]
fn sort_pellet_candidates_buffered(values: &mut [PelletCandidate]) {
    let mut scratch = [PelletCandidate {pellet: 0, distance_squared: DistanceOrderKey(0)};
        PELLET_RADIX_CAPACITY];
    sort_pellet_partitions(values, &mut scratch[..values.len()]);
}

fn sort_pellet_partitions(values: &mut [PelletCandidate], scratch: &mut [PelletCandidate]) {
    if values.len() <= 64 {
        values.sort_unstable_by(compare_pellet_candidates);
        return;
    }
    let first = values[0].distance_squared.0 as u64;
    let differing = values.iter().fold(0, |bits, value| bits | (first ^ value.distance_squared.0 as u64));
    if differing == 0 {
        values.sort_unstable_by(compare_pellet_candidates);
        return;
    }
    let shift = (63 - differing.leading_zeros()).saturating_sub(3);
    let digit = |value: &PelletCandidate| {
        (((value.distance_squared.0 as u64 ^ (1 << 63)) >> shift) & 15) as usize
    };
    let mut ends = [0usize; 16];
    for value in values.iter() { ends[digit(value)] += 1; }
    let mut next = [0usize; 16];
    let mut offset = 0;
    for bucket in 0..16 {
        next[bucket] = offset;
        offset += ends[bucket];
        ends[bucket] = offset;
    }
    for value in values.iter() {
        let bucket = digit(value);
        scratch[next[bucket]] = *value;
        next[bucket] += 1;
    }
    let mut start = 0;
    for end in ends {
        if end - start > 1 {
            sort_pellet_partitions(&mut scratch[start..end], &mut values[start..end]);
        }
        start = end;
    }
    values.copy_from_slice(scratch);
}

fn build_max_heap<T>(values: &mut [T], compare: fn(&T, &T) -> Ordering) {
    if values.len() < 2 {
        return;
    }
    for parent in (0..=(values.len() - 2) / 2).rev() {
        sift_max_heap_down(values, parent, compare);
    }
}

fn sift_max_heap_down<T>(values: &mut [T], mut parent: usize, compare: fn(&T, &T) -> Ordering) {
    loop {
        let left = parent * 2 + 1;
        if left >= values.len() {
            return;
        }
        let right = left + 1;
        let largest =
            if right < values.len() && compare(&values[left], &values[right]) == Ordering::Less {
                right
            } else {
                left
            };
        if compare(&values[parent], &values[largest]) != Ordering::Less {
            return;
        }
        values.swap(parent, largest);
        parent = largest;
    }
}

fn pellet_radix_order_matches_comparison_for_key_extremes_ties_and_heap_inputs() {
        let mut state = 0x4d59_5df4_d0f3_3173u64;
        for length in [
            0, 1, 31, 32, 63, 64, 65, 127, 128, 129, 899, 900, 901, 3000, 4096,
        ] {
            for shape in 0..6 {
                let mut values: Vec<_> = (0..length)
                    .map(|ordinal| {
                        state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
                        let key = match shape {
                            0 => state as i64,
                            1 => (state & 0xff) as i64,
                            2 => i64::MIN + (state & 0xffff) as i64,
                            3 => i64::MAX - (state & 0xffff) as i64,
                            4 => 0,
                            _ => (ordinal / 16) as i64,
                        };
                        PelletCandidate {
                            pellet: usize::MAX - ordinal,
                            distance_squared: DistanceOrderKey(key),
                        }
                    })
                    .collect();
                let mut expected = values.clone();
                expected.sort_unstable_by(compare_pellet_candidates);
                for order in 0..3 {
                    match order {
                        0 => {}
                        1 => values.reverse(),
                        _ => build_max_heap(&mut values, compare_pellet_candidates),
                    }
                    let capacity = values.capacity();
                    sort_pellet_candidates(&mut values);
                    assert_eq!(
                        values, expected,
                        "length={length} shape={shape} order={order}"
                    );
                    assert_eq!(values.capacity(), capacity);
                }
            }
        }
        // A long shared-prefix chain reaches every radix level before a large
        // equal-distance leaf; ordinals still break all ties exactly.
        let mut chain: Vec<_> = (0..1024)
            .map(|ordinal| PelletCandidate {
                pellet: usize::MAX - ordinal,
                distance_squared: DistanceOrderKey(0),
            })
            .collect();
        for bit in 0..64 {
            chain.push(PelletCandidate {
                pellet: bit,
                distance_squared: DistanceOrderKey((1u64 << bit) as i64),
            });
        }
        let mut expected = chain.clone();
        expected.sort_unstable_by(compare_pellet_candidates);
        sort_pellet_candidates(&mut chain);
        assert_eq!(chain, expected);
    }

fn measure(template: &[PelletCandidate], radix: bool, repetitions: usize) -> u128 {
    let mut values=template.to_vec();
    let started=std::time::Instant::now();
    for _ in 0..repetitions {
        values.copy_from_slice(template);
        let slice=std::hint::black_box(values.as_mut_slice());
        if radix { sort_pellet_candidates(slice); }
        else { slice.sort_unstable_by(compare_pellet_candidates); }
        std::hint::black_box(&values);
    }
    started.elapsed().as_nanos()
}
fn main() {
    pellet_radix_order_matches_comparison_for_key_extremes_ties_and_heap_inputs();
    let mut random=0x4d595df4d0f33173u64;
    for length in [32usize,64,65,128,256,512,900,2200,3000] {
        for shape in ["radius","prefix","equal","heap","sorted","reverse"] {
            let mut template: Vec<_>=(0..length).map(|ordinal| {
                random=random.wrapping_mul(6364136223846793005).wrapping_add(1);
                let key=match shape {
                    "prefix" => (0x4130000000000000u64 | (random & 0xffff)) as i64,
                    "equal" => 0,
                    _ => (((random >> 11) as f64) * (1.0/9007199254740992.0) * 1000000.0).to_bits() as i64,
                };
                PelletCandidate {pellet:usize::MAX-ordinal,distance_squared:DistanceOrderKey(key)}
            }).collect();
            match shape {
                "heap" => build_max_heap(&mut template,compare_pellet_candidates),
                "sorted" => template.sort_unstable_by(compare_pellet_candidates),
                "reverse" => template.sort_unstable_by(|a,b|compare_pellet_candidates(b,a)),
                _ => {}
            }
            let mut expected=template.clone();
            expected.sort_unstable_by(compare_pellet_candidates);
            let mut actual=template.clone();sort_pellet_candidates(&mut actual);assert_eq!(actual,expected);
            let repetitions=(1000000/length).clamp(500,10000);
            let times=[measure(&template,false,repetitions),measure(&template,true,repetitions),
                       measure(&template,true,repetitions),measure(&template,false,repetitions)];
            println!("{{\"length\":{},\"shape\":\"{}\",\"repetitions\":{},\"nanoseconds\":{:?}}}",length,shape,repetitions,times);
        }
    }
}


"""Compare scoped CPU dispatch environments on identical retained exports."""
from pathlib import Path
import sys,json,os
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[2]/'native/target/live-replay-occupancy-20261023/pyrl'))
from pyrl_trainer.distillation_process import configure_cli_priority
configure_cli_priority()
import torch
from pyrl_trainer.canonical_graph import CanonicalGraphManifest,CanonicalGraph
from pyrl_trainer.canonical_parity import _floats,_sequence
torch.set_num_threads(2)
records=[]
for kind in ['gru','lstm','rru']:
 case=root/'roundtrip-corrected-debian'/('large-'+kind)
 trained=root/'roundtrip-debian-all'/('cpu-'+kind)
 manifest=CanonicalGraphManifest.read(trained/'rust-scalar-v1/manifest.json')
 model=CanonicalGraph(manifest,(trained/'trained.f32').read_bytes(),'cpu')
 observations=_floats(case/'observations.f32',manifest.input_size,'cpu')
 initial=_floats(case/'initial-state.f32',manifest.total_state_size,'cpu')
 actual,states=_sequence(model,observations,initial)
 for backend in ['rust-scalar-v1','rust-sse2-v1']:
  output=_floats(trained/backend/'outputs.f32',2,'cpu')
  recurrent=_floats(trained/backend/'states.f32',manifest.total_state_size,'cpu')
  checks={}
  for name,x,y in [('output',actual,output),('state',states,recurrent)]:
   checks[name]={'firstFailures':int(((x[0]-y[0]).abs()>1e-5+1e-4*y[0].abs()).sum()),
                 'longFailures':int(((x-y).abs()>1e-3+1e-3*y.abs()).sum()),
                 'firstMaxAbs':(x[0]-y[0]).abs().max().item(),'longMaxAbs':(x-y).abs().max().item()}
  records.append({'case':kind,'backend':backend,'checks':checks})
report={'cpuCapability':torch.backends.cpu.get_cpu_capability(),
        'MKL_CBWR':os.environ.get('MKL_CBWR'),'ATEN_CPU_CAPABILITY':os.environ.get('ATEN_CPU_CAPABILITY'),
        'records':records}
print(json.dumps(report))

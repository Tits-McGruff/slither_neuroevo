"""Exercise actual optimizer roundtrips with a scoped compensated Float32 CPU matmul."""
from pathlib import Path
import sys,json,hashlib
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[2]/'native/target/live-replay-occupancy-20261023/pyrl'))
from pyrl_trainer.distillation_process import configure_cli_priority
priority=configure_cli_priority()
import torch
from pyrl_trainer.canonical_parity import run_gate,_case
torch.set_num_threads(2)
original=torch.Tensor.__matmul__
def stable(left,right):
 if left.device.type!='cpu' or left.shape[-1]<=128:return original(left,right)
 total=torch.zeros(left.shape[0],right.shape[-1],dtype=left.dtype,device=left.device)
 correction=torch.zeros_like(total)
 for start in range(0,left.shape[-1],128):
  part=original(left[...,start:start+128],right[start:start+128])
  updated=total+part
  delta=torch.where(total.abs()>=part.abs(),(total-updated)+part,(part-updated)+total)
  finite=updated.isfinite()&total.isfinite()&part.isfinite()
  correction=torch.where(finite,correction+delta,torch.zeros_like(correction))
  total=updated
 return torch.where(total.isfinite(),total+correction,total)
torch.Tensor.__matmul__=stable
try:
 runner=root.parent/'release/canonical-training-graph'
 fixture=root/'roundtrip-corrected-debian'
 report=run_gate(runner,fixture/'fixtures','cpu')
 for kind in ['gru','lstm','rru']:
  report['cases'].extend(_case(runner,fixture/('large-'+kind),'large-'+kind,'cpu'))
 report.update({'prototype':True,'cpuMatmulBlock':128,'processPriority':priority,
                'driverSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
 (root/'stable-cpu-optimizer-probe.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'roundtrips':len(report['cases']),'passed':True,
                   'maxStateError':max(x['stateErrorGrowth'][-1]['maxAbs'] for x in report['cases'])}))
finally:torch.Tensor.__matmul__=original

"""Bounded actual optimizer parity for every standard and wide recurrent graph."""
import argparse,hashlib,json,os,runpy,shutil,subprocess,sys,time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument("--pyrl-root",type=Path,required=True)
parser.add_argument("--runner",type=Path,required=True)
parser.add_argument("--directory",type=Path,required=True)
parser.add_argument("--observer",type=Path,required=True)
parser.add_argument("--devices",nargs="+",choices=["cpu","cuda"],required=True)
args=parser.parse_args()
root=args.directory.resolve();root.mkdir()
assert shutil.disk_usage(root).free>8*1024**3
sys.path.insert(0,str(args.pyrl_root.resolve()))
from pyrl_trainer.distillation_process import configure_cli_priority
priority=configure_cli_priority()
import torch
from pyrl_trainer.canonical_parity import run_gate
torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
observer=subprocess.Popen([sys.executable,"-B",str(args.observer.resolve()),
 "--output",str(root/"resources.jsonl"),"--interval-seconds","30","--samples","120",
 "--watch-pid",str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
started=time.monotonic()
try:
 resource_path=root/"resources.jsonl"
 resource_deadline=time.monotonic()+60
 while not resource_path.exists() or resource_path.stat().st_size==0:
  assert observer.poll() is None,"aggregate observer exited before first sample"
  assert time.monotonic()<resource_deadline,"aggregate observer startup deadline"
  time.sleep(0.1)
 generator=args.pyrl_root/"scripts/generate_canonical_graph_fixtures.py"
 generate=runpy.run_path(str(generator))["generate"]
 generate(args.runner.resolve(),root/"fixtures",include_large=True)
 for device in args.devices:
  if device=="cuda":
   assert torch.cuda.is_available(),"CUDA environment is required"
   free,total=torch.cuda.mem_get_info()
   assert free>=4608*1024**2,"CUDA free-memory admission"
   torch.cuda.set_per_process_memory_fraction(4096*1024**2/total)
   torch.cuda.reset_peak_memory_stats()
  before=time.monotonic()
  report=run_gate(args.runner,root/"fixtures",device,include_large=True)
  assert observer.poll() is None,"aggregate observer exited during qualification"
  assert len(report["cases"])==18
  assert all(x["nativeSourceSha256"]=="7ae9e5293fbad1b7cc232c9e40bfc9033b117fe4bc4468896af9b69b5f52b156" for x in report["cases"])
  report.update({"cpuThreads":2,"processPriority":priority,
    "driverSha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "generatorSha256":hashlib.sha256(generator.read_bytes()).hexdigest(),
    "elapsedSeconds":time.monotonic()-before,"scope":"Actual standard and --include-large generator/optimizer gate. Unchanged first-delivery CPU 1e-5/CUDA 1e-4 absolute and 1e-4 relative bounds, plus 256-delivery 1e-3 absolute/relative bounds. Synthetic numeric qualification; no CPU training throughput, gameplay maturity, idle-host or integrated-capacity claim."})
  if device=="cuda":
   report.update({"deviceMemoryBudgetMiB":4096,"peakReservedDeviceBytes":torch.cuda.max_memory_reserved(),"peakAllocatedDeviceBytes":torch.cuda.max_memory_allocated()})
  (root/(device+"-roundtrip.json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
  print(json.dumps({"device":device,"roundtrips":len(report["cases"]),"passed":True}),flush=True)
finally:
 observer.terminate()
 try:observer.wait(timeout=10)
 except subprocess.TimeoutExpired:observer.kill();observer.wait()
 (root/"status.json").write_text(json.dumps({"elapsedSeconds":time.monotonic()-started,
  "completedDevices":[x for x in args.devices if (root/(x+"-roundtrip.json")).exists()]})+"\n",encoding="utf-8")
